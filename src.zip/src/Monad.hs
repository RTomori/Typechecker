{-# LANGUAGE FlexibleInstances     #-}
{-# LANGUAGE InstanceSigs          #-}
{-# LANGUAGE MultiParamTypeClasses #-}
module Monad (TI(runInfer), extendEnv,lookupEnv, newTyVar,shrinkEnv, inferInEnv) where

import           Control.Monad.Reader (MonadReader (ask, local),
                                       MonadTrans (lift))
import           Control.Monad.State  (MonadState (get, put, state))
import           Data.Map             (delete, insert, lookup)
import           Syntax               (Env, Name, Sigma, Type (TyVar), Uniq,Tau)

newtype TI m a = TI {runInfer :: Env -> Uniq -> m (a, Uniq)}

instance Monad m => Functor (TI m) where
  fmap g (TI f) = TI(\env uq -> do{
                         (x, u) <- f env uq;
                         return (g x, u)
                                   })
instance Monad m => Applicative (TI m) where
  pure x = TI(\_ uq -> pure (x, uq))
  TI f <*> TI x = TI(\env uq -> do{
                         (f', u1) <- f env uq;
                         (x', u2) <- x env u1;
                         pure (f' x', u2)
                                   })
instance Monad m => Monad (TI m) where
  TI f >>= g = TI(\env uq -> do{
                      (x, u1) <- f env uq;
                       let  TI {runInfer = g'} = g x in g' env u1
                                })
instance MonadFail m => MonadFail (TI m) where
  fail err = TI(\_ uq -> do{
                    e' <- fail err;
                    pure (e', uq)})

instance MonadTrans TI where
  lift m = TI (\_ uq -> m >>= \x -> pure (x, uq))

instance Monad m => MonadReader Env (TI m) where
  ask = TI(curry pure)
  local s (TI f) = TI(f. s)

instance Monad m => MonadState Uniq (TI m) where
  state trans = TI (\_ uq -> do{let (x, u') = trans uq in pure (x, u')})

extendEnv :: Monad m => Name -> Sigma -> TI m a -> TI m a
extendEnv x ty = local (insert x ty)

-- | the dual of `extendEnv`
shrinkEnv :: Monad m => Name -> TI m a -> TI m a
shrinkEnv x = local (delete x)

-- |
inferInEnv :: Monad m => Env -> TI m a -> TI m a
inferInEnv e =
  local (const e)
newTyVar :: Monad m => TI m Tau
newTyVar = do{
  u <- get;
  put (u + 1);
  pure $ TyVar u;
             }
-- | lookup the type of variable in given context
lookupEnv :: MonadFail m => Name -> TI m Sigma
lookupEnv x = do{
  env <- ask;
  case Data.Map.lookup x env of
     Just ty -> pure ty
     Nothing -> fail $ "Not in scope '" ++ x ++ "'"}
