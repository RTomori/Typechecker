{-# LANGUAGE OverloadedStrings #-}
module Parser where

import           Control.Monad.Combinators.Expr (Operator (InfixL, InfixR, Prefix, TernR),
                                                 makeExprParser)
import           Data.Text                      (Text)
import           Data.Void
import           Syntax
import           Text.Megaparsec                (Parsec, between, choice, many,
                                                 try, (<?>), (<|>))
import           Text.Megaparsec.Char           (alphaNumChar, letterChar,
                                                 space1, string)
import qualified Text.Megaparsec.Char.Lexer     as L
type Parser = Parsec Void Text
sc :: Parser ()
sc = L.space space1 (L.skipLineComment "--") (L.skipBlockComment "(*" "*)")

lexeme :: Parser a -> Parser a
lexeme = L.lexeme sc

parens :: Parser a -> Parser a
parens = between (L.symbol sc "(") (L.symbol sc ")")

many1 :: Parser a -> Parser [a]
many1 p = do
  x <- p
  xs <- many p
  pure (x:xs)
variable :: Parser String
variable = lexeme ((:) <$> letterChar <*> many alphaNumChar <?> "variable")

parseVar :: Parser Term
parseVar = TmVar <$> variable

parseAbs :: Parser Term
parseAbs = do
  _ <- reserved "fun"
  args <- many variable
  _ <- reserved "->"
  body <- parseExpr
  pure (foldr TmAbs body args)

parseRec :: Parser Term
parseRec = do
  _ <- reserved "rec" >> reserved "{"
  arg <- variable
  _ <- reserved "="
  body <- parseExpr
  _ <- reserved "}"
  pure (TmRec arg body)


reserved :: Text -> Parser Text
reserved s = lexeme $ string s

parseInt :: Parser Term
parseInt = do
  n <- lexeme L.decimal
  pure (TmLit (LInt n))


parseBool :: Parser Term
parseBool = lexeme (string "true" >> pure (TmLit (LBool True))) <|>
            lexeme (string "false" >> pure (TmLit (LBool False)))

parseNil :: Parser Term
parseNil = lexeme (string "[]" >> pure (TmConst Nil))


parseAExp :: Parser Term
parseAExp =
  parens parseExpr <|>
  parseBool <|>
  parseInt <|>
  parseNil <|>
  parseRec <|>
  parseAbs <|>
  parseVar

parseTerm :: Parser Term
parseTerm = parseAExp >>= \x -> (many1 parseAExp >>= \xs -> pure (foldl TmApp x xs)) <|> pure x

prefix :: Text -> (Term -> Term) -> Operator Parser Term
prefix name f = Prefix (f <$ L.symbol sc name)

binary :: Text -> (Term -> Term -> Term) -> Operator Parser Term
binary name f = InfixL (f <$ L.symbol sc name)

-- trinary :: Text -> (Term -> Term -> Term -> Term) -> Operator Parser Term
-- trinary name f = TernR (f <$ L.symbol sc name)

opTable :: [[Operator Parser Term]]
opTable = [[prefix "not" (TmApp (TmConst Not)),
            prefix "fst" (TmApp (TmConst Fst)),
            prefix "snd" (TmApp (TmConst Snd)),
            prefix "null" (TmApp (TmConst Null)),
            prefix "hd" (TmApp (TmConst Hd)),
            prefix "tl" (TmApp (TmConst Tl)),
            binary "||" (\t1 t2 -> TmApp (TmConst Or) (TmApp (TmApp (TmConst Pair) t1) t2))],
            [binary "," (\t1 t2 -> TmApp (TmApp (TmConst Pair) t1) t2),
            InfixR ((TmApp . TmApp (TmConst Cons)) <$ L.symbol sc ":"),
            binary "&&" (\t1 t2 -> TmApp (TmConst And) (TmApp (TmApp (TmConst Pair) t1) t2)),
            binary "*" (\t1 t2 -> TmApp (TmConst Times) (TmApp (TmApp (TmConst Pair) t1) t2))],
            [binary "+" (\t1 t2 -> TmApp (TmConst Plus) (TmApp (TmApp (TmConst Pair) t1) t2)),
            binary "-" (\t1 t2 -> TmApp (TmConst Minus) (TmApp (TmApp (TmConst Pair) t1) t2))],
            [binary "==" (\t1 t2 -> TmApp (TmConst Eq) (TmApp (TmApp (TmConst Pair) t1) t2)),
            binary "<" (\t1 t2 -> TmApp (TmConst Lt) (TmApp (TmApp (TmConst Pair) t1) t2))],
            [TernR (((\t1 t2 t3 -> (TmApp (TmApp (TmApp (TmConst Ifc) t1) t2) t3)) <$ L.symbol sc ":") <$ L.symbol sc "?")]]
parseExpr :: Parser Term
parseExpr = makeExprParser parseTerm opTable
