{-# LANGUAGE Strict #-}
module Infer where
import           Control.Monad              (forM)
import           Control.Monad.Catch        (MonadThrow)
import           Control.Monad.Except       (runExceptT)
import           Control.Monad.Reader
import           Control.Monad.Reader.Class (MonadReader (ask))
import           Control.Monad.State        (get, put)
import           Data.Map.Strict            (delete, elems, fromList, insert,
                                             intersectionWith, lookup, map,
                                             singleton, union, update, (!))
import qualified Data.Map.Strict            as Map (lookup)
import           Data.Set                   (Set, difference, empty, member)
import qualified Data.Set                   as Set (fromList, singleton, toList,
                                                    union)
import           Monad                      (TI (runInfer), extendEnv,
                                             inferInEnv, lookupEnv, newTyVar)
import           Subst                      (Subst, apply, compose)
import           Syntax                     (Const (Nil), Env,
                                             Lit (LBool, LInt), Sigma, Tau,
                                             Term (TmAbs, TmApp, TmConst, TmLit, TmRec, TmVar),
                                             TyCon (TyBool, TyInt),
                                             Type (TyAll, TyCon, TyFun, TyList, TyProd, TyVar),
                                             Uniq, consts, emptyEnv, fVar)
import           Unify                      (unify)

freeTyVar :: Type -> Set Uniq
freeTyVar (TyCon _)        = empty
freeTyVar (TyVar n)        = Set.singleton n
freeTyVar (TyFun ty1 ty2)  = freeTyVar ty1 `Set.union` freeTyVar ty2
freeTyVar (TyAll ns ts)    = freeTyVar ts `difference` Set.fromList ns
freeTyVar (TyProd ty1 ty2) = freeTyVar ty1 `Set.union` freeTyVar ty2
freeTyVar (TyList t)       = freeTyVar t

-- enumerate free type variables within typing context
freeInEnv :: Env -> Set Uniq
freeInEnv env = mconcat (Prelude.map freeTyVar (elems env))


newSubst :: [Uniq] -> [Type] -> Subst
newSubst ns ts = fromList $ zip ns ts

-- | Removes quantification from polymorphic types, and
-- |if the environment is nonempty, substitute type variables with types with corresponding indices.
instantiate :: Monad m => Env -> Sigma -> TI m (Env, Tau)
instantiate env (TyAll ns ty) = do{
  tvs <- mapM (const newTyVar) ns;
  let s = newSubst ns tvs in pure (Data.Map.Strict.map (apply s) env, apply s ty)
                              }
instantiate env ty = pure (env, ty)
-- | Unlike Damas-Milner's algorithm, the inference algorithm
-- | updates environment, not substitution.


-- inferTau :: MonadFail m => Int -> Term -> TI m (Env,Tau)
-- inferTau k (TmVar n) = do
--   env <- ask
--   sigma <- lookupEnv n
--   instantiate env sigma

infer :: MonadFail m => Int -> Term -> TI m (Env, Tau)
infer _ (TmVar x) = do
  env <- ask
  case Map.lookup x env of
    Just u -> do{
      instantiate env u;
    }
    Nothing -> do{
    -- {x:a.a}
     a <- newTyVar;
     pure (Data.Map.Strict.singleton x a, a)
    }
infer k (TmAbs x e) = do{
  (env', u0) <- infer k e;
  if Data.Set.member x (fVar e)
  -- x \in FV(e0) \and U = U',x:u --> <U',u\to u0>
    then do{
      case Map.lookup x env' of
        Just u  -> pure (delete x env', TyFun u u0)
        Nothing -> fail "unreachable"
    }
    else do{
      a <- newTyVar;
      pure (env',TyFun a u0)
    }
}
infer k (TmApp t0 t1) = do{
  (env, u0) <- inferInEnv emptyEnv $ infer k t0;
  case u0 of
    TyVar a -> do{
      a1 <- newTyVar;
      a2 <- newTyVar;
      (env1, u1) <- inferInEnv emptyEnv $ infer k t1;
      s <- unify ([(u1, a1),(u0, TyFun a1 a2)] ++ elems (intersectionWith (,) env env1));
      let env' = env `union` env1 in
      let env'' =  Data.Map.Strict.map (apply s) env' in
      pure (env'', apply s a2)
    }
    TyFun u2 u -> do{
      (env1, u1) <- inferInEnv emptyEnv (infer k t1);
      s <- unify ((u1, u2) :elems (intersectionWith (,) env env1));
      let env' = env `union` env1 in
      pure (Data.Map.Strict.map (apply s) env', apply s u)
    }
    _ -> fail "unreachable"
}

infer 1 (TmRec x _) = do{
  a <- newTyVar;
  env <- ask;
  pure (insert x a env, a)
}
infer k (TmRec x t) = do
  (e0, u') <- inferInEnv emptyEnv (infer k t);
  case (Data.Map.Strict.lookup x e0) of
     Just u -> do{
       s <- unify[(u,u')];
       pure (Data.Map.Strict.map (apply s) e0, apply s u)
     };
     Nothing -> do{
  (env, tau) <- infer (k - 1) t;
  case Data.Map.Strict.lookup x env of
    Just ty -> inferInEnv (update (\u -> if u == ty then Just tau else Nothing) x env) (infer k t)
    Nothing -> fail "unreachable"
}

infer _ (TmConst c) = instantiate emptyEnv (consts ! c)
infer _ (TmLit (LInt _)) = pure (emptyEnv, TyCon TyInt)
infer _ (TmLit (LBool _)) = pure (emptyEnv, TyCon TyBool)



generalize :: Monad m => Tau -> TI m Sigma
generalize ty = do
        env <- ask
        let ns = Set.toList $ freeTyVar ty `difference` freeInEnv env
        return $ if null ns then ty else TyAll ns ty

inferSigma :: MonadFail m => Int -> Term -> TI m Sigma
inferSigma k t = do
        (_, tau) <- infer k t
        generalize tau

inferType :: MonadFail m => Int -> Term -> m Type
inferType k t = fst <$> runInfer (inferSigma k t) emptyEnv 0

